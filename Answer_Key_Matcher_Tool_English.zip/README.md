# Universal Answer Key Matcher & Verifier Tool

An automated verification tool designed for test series and entrance exams (JEE, NEET, MHT-CET, NSAT, Foundation).

## Key Features:
- Universal PDF parser supporting formats such as `1. (B)`, `1. [B]`, `1. B`, `1 - B`, `1: B`, and multi-column tables.
- Bi-directional automatic mapping between letters (`A, B, C, D`) and numbers (`1, 2, 3, 4`).
- Automatic detection of Question and Answer columns in Excel spreadsheets.
- Highlights discrepancies, missing questions, and mismatches in a clean dashboard.
- Exports complete verification reports to Excel format.

## How to Run:
```bash
pip install -r requirements.txt
streamlit run app.py
```
