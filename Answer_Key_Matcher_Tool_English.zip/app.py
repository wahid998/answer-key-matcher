import streamlit as st
import pandas as pd
import pypdf
import re
import io

st.set_page_config(page_title="Universal Answer Key Matcher", page_icon="🎯", layout="wide")

st.markdown("""
<style>
    .metric-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        border: 1px solid #e9ecef;
    }
</style>
""", unsafe_allow_html=True)

st.title("🎯 Universal Answer Key Matcher & Verifier")
st.caption("Supports all exam PDF formats (brackets like (A), without brackets A, numeric 1234, multi-column tables, dots) and matches directly with Excel Answer Keys.")

# Normalization maps
alpha_to_num = {'A': '1', 'B': '2', 'C': '3', 'D': '4', 'E': '5'}
num_to_alpha = {'1': 'A', '2': 'B', '3': 'C', '4': 'D', '5': 'E'}

def normalize_val(val):
    if pd.isna(val) or val is None:
        return ""
    val_str = str(val).strip().upper()
    if val_str.endswith(".0"):
        val_str = val_str[:-2]
    val_str = re.sub(r'^(OPTION|OPT|ANS|ANSWER|CHOICE)[\s\:\-\.]*', '', val_str, flags=re.IGNORECASE).strip()
    return re.sub(r'[\(\)\[\]\{\}\.\,\:\s\-_]', '', val_str)

def get_standard_forms(val):
    clean = normalize_val(val)
    if not clean:
        return "", ""
    if clean in alpha_to_num:
        return clean, alpha_to_num[clean]
    elif clean in num_to_alpha:
        return num_to_alpha[clean], clean
    return clean, clean

def extract_answers_from_pdf(pdf_file):
    reader = pypdf.PdfReader(pdf_file)
    extracted = {}
    full_text = ""
    for page in reader.pages:
        txt = page.extract_text()
        if txt:
            full_text += txt + "\n"

    patterns = [
        r'(?:Q(?:ues(?:tion)?)?\.?\s*)?(\d{1,3})[\s\.\:\-\—]+[\(\[\{]?([A-Ea-e1-4])[\)\]\}]?',
        r'(?:Q(?:ues(?:tion)?)?\.?\s*)?(\d{1,3})\s*[\(\[\{]([A-Ea-e1-4])[\)\]\}]',
        r'(?:^|\s)(\d{1,3})\s+([A-Ea-e1-4])(?=\s|$)'
    ]

    for pat in patterns:
        matches = re.findall(pat, full_text, re.IGNORECASE)
        for q, ans in matches:
            try:
                q_num = int(q)
                if 1 <= q_num <= 300 and q_num not in extracted:
                    let, num = get_standard_forms(ans)
                    extracted[q_num] = {'letter': let, 'num': num, 'raw': ans.upper()}
            except:
                continue

    return extracted, full_text

def extract_answers_from_excel(excel_file):
    excel_answers = {}
    df = pd.read_excel(excel_file)
    
    q_col = None
    ans_col = None
    
    q_candidates = ['question number', 'question_number', 'question_no', 'question no', 'display order*', 'display order', 'q.no', 'qno', 'qid', 'sr no', 'sl no', 'q_num']
    for candidate in q_candidates:
        for col in df.columns:
            if candidate == str(col).strip().lower():
                q_col = col; break
        if q_col: break
            
    if q_col is None:
        for col in df.columns:
            col_l = str(col).lower()
            if 'question' in col_l or 'order' in col_l:
                q_col = col; break
    if q_col is None:
        q_col = df.columns[0]

    ans_candidates = ['answer', 'answer key', 'correct option', 'correct answer', 'correct ans', 'ans', 'key', 'option']
    for candidate in ans_candidates:
        for col in df.columns:
            if candidate == str(col).strip().lower():
                ans_col = col; break
        if ans_col: break
            
    if ans_col is None:
        for col in df.columns:
            col_l = str(col).lower()
            if 'answer' in col_l or 'ans' in col_l or 'key' in col_l:
                ans_col = col; break
    if ans_col is None:
        ans_col = df.columns[1] if len(df.columns) > 1 else df.columns[0]

    for _, row in df.iterrows():
        try:
            q_val = row[q_col]
            if pd.isna(q_val):
                continue
            q_num = int(float(q_val))
            ans_val = row[ans_col]
            let, num = get_standard_forms(ans_val)
            excel_answers[q_num] = {'letter': let, 'num': num, 'raw': str(ans_val).strip()}
        except (ValueError, TypeError):
            continue
            
    return excel_answers, q_col, ans_col

col1, col2 = st.columns(2)
with col1:
    pdf_file = st.file_uploader("📂 Upload PDF Answer Key", type=["pdf"])
with col2:
    excel_file = st.file_uploader("📂 Upload Excel File (.xlsx / .xls)", type=["xlsx", "xls"])

if pdf_file and excel_file:
    with st.spinner("Processing & Verifying Keys..."):
        try:
            pdf_data, raw_pdf_text = extract_answers_from_pdf(pdf_file)
            excel_data, detected_q_col, detected_ans_col = extract_answers_from_excel(excel_file)
            
            st.info(f"Detected ➔ PDF Questions: **{len(pdf_data)}** | Excel Questions: **{len(excel_data)}** (Detected Columns: `{detected_q_col}`, `{detected_ans_col}`)")
            
            all_questions = sorted(set(pdf_data.keys()).union(set(excel_data.keys())))
            
            mismatches = []
            full_table = []
            matched_count = 0
            
            for q in all_questions:
                p_item = pdf_data.get(q)
                e_item = excel_data.get(q)
                
                p_let = p_item['letter'] if p_item else None
                p_num = p_item['num'] if p_item else None
                e_let = e_item['letter'] if e_item else None
                e_num = e_item['num'] if e_item else None
                
                is_match = False
                reason = ""
                if p_item is None:
                    reason = "Question not found in PDF"
                elif e_item is None:
                    reason = "Question not found in Excel"
                elif p_num == e_num or p_let == e_let:
                    is_match = True
                else:
                    reason = "Option Mismatch"
                
                if is_match:
                    matched_count += 1
                    status = "✅ Matched"
                else:
                    status = "❌ Mismatch"
                    mismatches.append({
                        "Q.No": q,
                        "PDF Answer": f"{p_let} (Option {p_num})" if p_item else "❌ Missing in PDF",
                        "Excel Answer": f"{e_let} (Option {e_num})" if e_item else "❌ Missing in Excel",
                        "Reason": reason
                    })
                    
                full_table.append({
                    "Q.No": q,
                    "PDF Answer": f"{p_let} ({p_num})" if p_item else "Missing",
                    "Excel Answer": f"{e_let} ({e_num})" if e_item else "Missing",
                    "Status": status
                })
            
            total_q = len(all_questions)
            st.divider()
            m_col1, m_col2, m_col3 = st.columns(3)
            m_col1.metric("Total Questions", total_q)
            m_col2.metric("Matched ✅", matched_count)
            m_col3.metric("Mismatches ❌", len(mismatches))
            
            if len(mismatches) == 0 and total_q > 0:
                st.success(f"🎉 **ALL CORRECT!** All {total_q} questions matched perfectly!")
            else:
                st.error(f"⚠️ **Total {len(mismatches)} Discrepancies Found!** Review mismatched questions below:")
                st.table(pd.DataFrame(mismatches))
                
            with st.expander("📋 View Complete Verification Data (All Questions)"):
                st.dataframe(pd.DataFrame(full_table), use_container_width=True)
                
            report_df = pd.DataFrame(full_table)
            buffer = io.BytesIO()
            with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                report_df.to_excel(writer, index=False, sheet_name='Verification_Report')
            st.download_button(
                label="📥 Download Verification Report (.xlsx)",
                data=buffer.getvalue(),
                file_name="Answer_Key_Verification_Report.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            
        except Exception as e:
            st.error(f"Error processing files: {str(e)}")
